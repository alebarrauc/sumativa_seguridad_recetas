package com.sum.recetario.repository;

import com.sum.recetario.model.Recipe;
import org.springframework.data.jpa.repository.JpaRepository;

public interface recipeRepository extends JpaRepository<Recipe, Long> {
}
