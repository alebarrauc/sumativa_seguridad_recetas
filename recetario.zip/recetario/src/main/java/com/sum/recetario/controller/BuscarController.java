package com.sum.recetario.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class BuscarController {

    @GetMapping("/buscar")
    public String buscarRecetas(Model model) {
        // Puedes agregar atributos al modelo si quieres mostrar datos en la vista
        // model.addAttribute("recetas", listaDeRecetas);

        return "buscar"; // Asegúrate de tener una plantilla llamada "buscar.html" en templates
    }
}

