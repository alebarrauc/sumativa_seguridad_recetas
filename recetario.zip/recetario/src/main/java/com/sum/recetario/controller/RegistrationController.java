package com.sum.recetario.controller;

import com.sum.recetario.model.User;
import com.sum.recetario.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class RegistrationController {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Autowired
    public RegistrationController(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @GetMapping("/register")
    public String showRegistrationForm(Model model) {
        model.addAttribute("user", new User()); // Agregar un objeto User vacío al modelo
        return "register";
    }

    @PostMapping("/register")
    public String registerUser(User user) {
        // Codificar la contraseña antes de guardarla
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        user.setRole("USER"); // Asigna el rol por defecto

        // Guardar el usuario en la base de datos
        userRepository.save(user);

        // Redirigir al login después del registro
        return "redirect:/login";
    }
}
