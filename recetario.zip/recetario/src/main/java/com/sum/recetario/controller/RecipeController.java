package com.sum.recetario.controller;

import com.sum.recetario.model.Recipe;
import com.sum.recetario.repository.recipeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class RecipeController {

    @Autowired
    private recipeRepository recipeRepository;

    @GetMapping("/addRecipe")
    public String showRecipeForm(Model model) {
        model.addAttribute("recipe", new Recipe());
        return "add-recipe";
    }

    @PostMapping("/addRecipe")
    public String submitRecipeForm(@ModelAttribute Recipe recipe) {
        recipeRepository.save(recipe);
        return "redirect:/addRecipe?success";
    }

     // Nuevo método para listar todas las recetas
     @GetMapping("/recipes")
     public String listRecipes(Model model) {
         List<Recipe> recipes = recipeRepository.findAll(); // Obtener todas las recetas
         model.addAttribute("recipes", recipes); // Enviar la lista a la vista
         return "list-recipes"; // Nombre de la vista Thymeleaf
     }
}
