package com.sum.recetario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecetarioApplicationTests {

	@Test
	void contextLoads() {
	}

}
